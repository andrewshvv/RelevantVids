console.info("chrome-ext template-react-js background script");chrome.tabs.onUpdated.addListener(function(e,s,t){s.url&&chrome.tabs.sendMessage(e,{message:"ON_URL_CHANGED"})});
